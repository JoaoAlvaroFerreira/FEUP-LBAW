-----------------------------------------
-- Populate the database
-----------------------------------------

INSERT INTO "user" (id,email,name,bio,password,photo,join_date,banned) VALUES (1,'eu@Uttincidunt.net','Sonya Barry','sit amet luctus vulputate,','NHX28PEG1XU','dignissim','10/18/2019','Yes');
INSERT INTO "user" (id,email,name,bio,password,photo,join_date,banned) VALUES (2,'ac.risus.Morbi@odioNaminterdum.co.uk','Thomas Robles','mollis lectus pede et','DOE56UOT0IG','nonummy','02/04/2020','No');
INSERT INTO "user" (id,email,name,bio,password,photo,join_date,banned) VALUES (3,'diam@ultriciesornare.com','Ginger Reid','sagittis felis. Donec tempor,','QUN10TNC0SI','nec','10/11/2019','Yes');
INSERT INTO "user" (id,email,name,bio,password,photo,join_date,banned) VALUES (4,'erat.nonummy.ultricies@tellus.co.uk','Urielle Marks','eleifend. Cras sed leo. Cras vehicula aliquet','NEG79HFK1SD','vitae','12/14/2019','Yes');
INSERT INTO "user" (id,email,name,bio,password,photo,join_date,banned) VALUES (5,'porttitor.scelerisque.neque@diamSeddiam.ca','Helen Mcdonald','a ultricies adipiscing, enim mi tempor','ZMX78XCV4FR','orci.','12/14/2019','No');
INSERT INTO "user" (id,email,name,bio,password,photo,join_date,banned) VALUES (6,'sit.amet.ultricies@Duisac.ca','Conan Jennings','et nunc. Quisque ornare tortor at risus. Nunc','VXI91NYK5XE','mi,','06/17/2019','No');
INSERT INTO "user" (id,email,name,bio,password,photo,join_date,banned) VALUES (7,'leo.Vivamus.nibh@ridiculusmus.edu','Martha Terry','feugiat non, lobortis quis, pede. Suspendisse dui.','AYY88RFN9II','nec,','08/17/2019','No');
INSERT INTO "user" (id,email,name,bio,password,photo,join_date,banned) VALUES (8,'eleifend.Cras.sed@sollicitudinadipiscing.org','Jerry Lyons','convallis ligula. Donec luctus aliquet','EYA52QLV7UQ','sed','03/03/2020','No');
INSERT INTO "user" (id,email,name,bio,password,photo,join_date,banned) VALUES (9,'Suspendisse.eleifend.Cras@rhoncusProinnisl.net','Lawrence Barton','Morbi vehicula. Pellentesque tincidunt','XAF27OYU6IV','arcu','01/26/2020','No');
INSERT INTO "user" (id,email,name,bio,password,photo,join_date,banned) VALUES (10,'vitae@felis.org','Germaine Butler','nibh lacinia orci, consectetuer','KDN66OIG9RT','elit.','12/01/2019','No');
INSERT INTO "user" (id,email,name,bio,password,photo,join_date,banned) VALUES (11,'faucibus.ut@lacus.ca','Calvin Noel','eu, ligula. Aenean euismod mauris eu','YOU85JKN9MM','dolor.','09/24/2019','No');
INSERT INTO "user" (id,email,name,bio,password,photo,join_date,banned) VALUES (12,'natoque.penatibus@leoinlobortis.net','Keane Leblanc','egestas nunc sed libero. Proin sed','GSY64LIZ9TQ','Proin','09/29/2019','No');
INSERT INTO "user" (id,email,name,bio,password,photo,join_date,banned) VALUES (13,'netus.et.malesuada@rutrumlorem.org','Nerea Doyle','magnis dis parturient montes, nascetur ridiculus mus.','IXD07QCS8MW','ante','01/05/2020','No');
INSERT INTO "user" (id,email,name,bio,password,photo,join_date,banned) VALUES (14,'eu@tinciduntpede.net','Jason Solomon','eu eros. Nam consequat dolor vitae dolor.','AWJ80AAY3NQ','lorem,','10/09/2019','No');
INSERT INTO "user" (id,email,name,bio,password,photo,join_date,banned) VALUES (15,'elit@pretium.edu','Chaim Brewer','magna. Nam ligula elit, pretium et, rutrum','HWU85QRC5ED','erat','06/24/2019','No');
INSERT INTO "user" (id,email,name,bio,password,photo,join_date,banned) VALUES (16,'Lorem.ipsum.dolor@ipsumsodalespurus.edu','Ora Alvarado','Nam porttitor scelerisque neque. Nullam nisl. Maecenas malesuada','OJE92XAA4PF','Aliquam','02/25/2020','No');
INSERT INTO "user" (id,email,name,bio,password,photo,join_date,banned) VALUES (17,'eu.turpis@magnaa.org','Arden Schmidt','sit amet risus. Donec egestas. Aliquam','VSK32ZAT3VN','ante','02/16/2020','No');
INSERT INTO "user" (id,email,name,bio,password,photo,join_date,banned) VALUES (18,'massa.Vestibulum.accumsan@Proinvel.ca','Veda Rush','sit amet, consectetuer adipiscing elit. Etiam laoreet, libero','HFZ76FHO7XS','id','01/23/2020','No');
INSERT INTO "user" (id,email,name,bio,password,photo,join_date,banned) VALUES (19,'Suspendisse.ac@nequevitae.com','Caldwell Williamson','Sed eget lacus. Mauris non dui nec','YDO27YES1PT','viverra.','07/23/2019','No');
INSERT INTO "user" (id,email,name,bio,password,photo,join_date,banned) VALUES (20,'erat@turpisegestas.edu','Aretha Graves','fringilla mi lacinia mattis. Integer eu lacus. Quisque','DCW91RRK9MK','gravida','03/20/2020','Yes');
INSERT INTO "user" (id,email,name,bio,password,photo,join_date,banned) VALUES (21,'elit.Curabitur.sed@Maecenasiaculis.co.uk','Macon Valentine','quam a felis ullamcorper viverra.','ZPC24REF9LC','sem','12/21/2019','No');
INSERT INTO "user" (id,email,name,bio,password,photo,join_date,banned) VALUES (22,'molestie.tortor@nonummyut.com','Brandon Joseph','et magnis dis parturient montes, nascetur ridiculus mus.','BBE84BNT9KZ','Nunc','07/28/2019','No');
INSERT INTO "user" (id,email,name,bio,password,photo,join_date,banned) VALUES (23,'imperdiet.nec@utcursusluctus.edu','Raymond Dotson','Aliquam erat volutpat. Nulla facilisis. Suspendisse','HIS36EHQ1IV','Sed','02/02/2020','No');
INSERT INTO "user" (id,email,name,bio,password,photo,join_date,banned) VALUES (24,'magna.Phasellus@ligulaNullam.com','Hayden Montoya','a, scelerisque sed, sapien. Nunc pulvinar arcu','QEJ25QHS7JJ','et','10/11/2019','No');
INSERT INTO "user" (id,email,name,bio,password,photo,join_date,banned) VALUES (25,'elit.pede@sitamet.ca','Quail Meyers','Phasellus dolor elit, pellentesque a, facilisis','ORM32NQB4OZ','eu','07/15/2019','No');
INSERT INTO "user" (id,email,name,bio,password,photo,join_date,banned) VALUES (26,'id.mollis.nec@lacusNullatincidunt.com','Athena Preston','elementum, lorem ut aliquam','JZM52YMV4MT','lectus','08/01/2019','No');
INSERT INTO "user" (id,email,name,bio,password,photo,join_date,banned) VALUES (27,'Duis.ac@adipiscing.co.uk','Sierra Macias','aliquet, metus urna convallis','OAM57QKS3IP','lectus','06/14/2019','No');
INSERT INTO "user" (id,email,name,bio,password,photo,join_date,banned) VALUES (28,'ligula.Nullam@miDuis.com','Fuller Park','Integer mollis. Integer tincidunt','BIH97QES5XN','sem','12/29/2019','No');
INSERT INTO "user" (id,email,name,bio,password,photo,join_date,banned) VALUES (29,'tincidunt.congue.turpis@metusvitaevelit.org','Tasha Dejesus','aliquet, metus urna convallis erat, eget tincidunt dui','KLC41QMG5YM','fringilla,','07/15/2019','No');
INSERT INTO "user" (id,email,name,bio,password,photo,join_date,banned) VALUES (30,'lacinia.vitae@velitdui.com','Odessa Burnett','sapien. Aenean massa. Integer vitae nibh. Donec est','UQI65IYJ0HS','aliquet','03/18/2020','No');


INSERT INTO "admin" (id,admin_date) VALUES (7,'08/19/2019');
INSERT INTO "admin" (id,admin_date) VALUES (8,'03/06/2020');
INSERT INTO "admin" (id,admin_date) VALUES (25,'09/15/2019');
INSERT INTO "admin" (id,admin_date) VALUES (28,'12/30/2019');
INSERT INTO "admin" (id,admin_date) VALUES (30,'03/20/2020');


INSERT INTO "event" (id,owner_id,name,description,price,start_date,end_date,location,removed) VALUES (1,10,'rutrum,','ipsum dolor sit amet, consectetuer adipiscing elit. Aliquam auctor,',14,'06/02/2020','11/08/2020','dolor,','No');
INSERT INTO "event" (id,owner_id,name,description,price,start_date,end_date,location,removed) VALUES (2,5,'pede','vulputate ullamcorper magna. Sed eu eros. Nam',19,'06/20/2020','10/19/2020','nibh enim,','No');
INSERT INTO "event" (id,owner_id,name,description,price,start_date,end_date,location,removed) VALUES (3,16,'accumsan','scelerisque sed, sapien. Nunc pulvinar arcu et pede. Nunc sed',39,'06/22/2020','01/18/2021','a, auctor non,','No');
INSERT INTO "event" (id,owner_id,name,description,price,start_date,end_date,location,removed) VALUES (4,6,'risus.','Sed','erat semper rutrum. Fusce dolor quam, elementum at, egestas a,',35,'06/12/2020','12/23/2020','auctor ullamcorper, nisl','Yes');
INSERT INTO "event" (id,owner_id,name,description,price,start_date,end_date,location,removed) VALUES (5,6,'Nulla','dictum eu, placerat eget, venenatis a, magna.',29,'06/09/2020','12/19/2020','mauris. Integer sem','Yes');
INSERT INTO "event" (id,owner_id,name,description,price,start_date,end_date,location,removed) VALUES (6,16,'sit','Cras interdum. Nunc sollicitudin commodo ipsum. Suspendisse non leo.',18,'06/11/2020','12/21/2020','Morbi quis','No');
INSERT INTO "event" (id,owner_id,name,description,price,start_date,end_date,location,removed) VALUES (7,3,'varius','ante. Vivamus non lorem vitae odio sagittis',7,'06/27/2020','09/30/2020','netus et malesuada','Yes');
INSERT INTO "event" (id,owner_id,name,description,price,start_date,end_date,location,removed) VALUES (8,30,'turpis','mauris elit, dictum eu, eleifend nec, malesuada ut, sem.',42,'06/09/2020','09/23/2020','neque pellentesque massa','Yes');
INSERT INTO "event" (id,owner_id,name,description,price,start_date,end_date,location,removed) VALUES (9,1,'ipsum','in, cursus et, eros. Proin ultrices. Duis volutpat',17,'06/05/2020','08/03/2020','sem, vitae aliquam','No');
INSERT INTO "event" (id,owner_id,name,description,price,start_date,end_date,location,removed) VALUES (10,11,'ante','nunc. In at pede. Cras vulputate velit eu sem.',31,'06/09/2020','01/14/2021','Duis a','No');
INSERT INTO "event" (id,owner_id,name,description,price,start_date,end_date,location,removed) VALUES (11,24,'congue','eu lacus. Quisque imperdiet, erat nonummy ultricies ornare,',9,'06/12/2020','11/29/2020','purus sapien,','Yes');
INSERT INTO "event" (id,owner_id,name,description,price,start_date,end_date,location,removed) VALUES (12,15,'Nullam','nunc interdum feugiat. Sed nec metus facilisis lorem tristique',35,'06/04/2020','08/26/2020','nec, mollis vitae,','Yes');
INSERT INTO "event" (id,owner_id,name,description,price,start_date,end_date,location,removed) VALUES (13,24,'diam','odio. Etiam ligula tortor, dictum eu, placerat',47,'06/01/2020','04/02/2021','euismod ac, fermentum','No');
INSERT INTO "event" (id,owner_id,name,description,price,start_date,end_date,location,removed) VALUES (14,25,'eu','ullamcorper, velit in aliquet lobortis, nisi nibh',39,'06/18/2020','11/05/2020','lobortis','Yes');
INSERT INTO "event" (id,owner_id,name,description,price,start_date,end_date,location,removed) VALUES (15,10,'eu','habitant morbi tristique senectus et netus et malesuada fames ac',40,'06/29/2020','08/27/2020','diam lorem,','Yes');
INSERT INTO "event" (id,owner_id,name,description,price,start_date,end_date,location,removed) VALUES (16,30,'adipiscing','mi. Duis risus odio, auctor vitae, aliquet nec,',31,'06/05/2020','09/19/2020','eu metus.','Yes');
INSERT INTO "event" (id,owner_id,name,description,price,start_date,end_date,location,removed) VALUES (17,7,'nibh.','rutrum non, hendrerit id, ante. Nunc mauris',15,'06/18/2020','02/02/2021','euismod ac,','Yes');
INSERT INTO "event" (id,owner_id,name,description,price,start_date,end_date,location,removed) VALUES (18,6,'eleifend','dui nec urna suscipit nonummy. Fusce fermentum fermentum arcu. Vestibulum',5,'06/10/2020','07/18/2020','fermentum fermentum arcu.','No');
INSERT INTO "event" (id,owner_id,name,description,price,start_date,end_date,location,removed) VALUES (19,7,'pede,','Aliquam gravida mauris ut mi. Duis',5,'06/10/2020','08/23/2020','egestas ligula. Nullam','Yes');
INSERT INTO "event" (id,owner_id,name,description,price,start_date,end_date,location,removed) VALUES (20,12,'magna','non sapien molestie orci tincidunt adipiscing. Mauris molestie',5,'06/22/2020','07/26/2020','felis. Nulla','No');


INSERT INTO "attending" (event_id,attendee_id) VALUES (12,3);
INSERT INTO "attending" (event_id,attendee_id) VALUES (16,22);
INSERT INTO "attending" (event_id,attendee_id) VALUES (15,22);
INSERT INTO "attending" (event_id,attendee_id) VALUES (5,26);
INSERT INTO "attending" (event_id,attendee_id) VALUES (15,11);
INSERT INTO "attending" (event_id,attendee_id) VALUES (7,9);
INSERT INTO "attending" (event_id,attendee_id) VALUES (7,8);
INSERT INTO "attending" (event_id,attendee_id) VALUES (4,30);
INSERT INTO "attending" (event_id,attendee_id) VALUES (20,5);
INSERT INTO "attending" (event_id,attendee_id) VALUES (7,19);
INSERT INTO "attending" (event_id,attendee_id) VALUES (5,29);
INSERT INTO "attending" (event_id,attendee_id) VALUES (19,1);
INSERT INTO "attending" (event_id,attendee_id) VALUES (2,8);
INSERT INTO "attending" (event_id,attendee_id) VALUES (14,27);
INSERT INTO "attending" (event_id,attendee_id) VALUES (8,20);
INSERT INTO "attending" (event_id,attendee_id) VALUES (17,8);
INSERT INTO "attending" (event_id,attendee_id) VALUES (9,1);
INSERT INTO "attending" (event_id,attendee_id) VALUES (2,27);
INSERT INTO "attending" (event_id,attendee_id) VALUES (16,11);
INSERT INTO "attending" (event_id,attendee_id) VALUES (20,6);


INSERT INTO "invited" (event_id,invited_id,inviter_id) VALUES (15,14,3);
INSERT INTO "invited" (event_id,invited_id,inviter_id) VALUES (9,20,20);
INSERT INTO "invited" (event_id,invited_id,inviter_id) VALUES (20,25,21);
INSERT INTO "invited" (event_id,invited_id,inviter_id) VALUES (6,21,5);
INSERT INTO "invited" (event_id,invited_id,inviter_id) VALUES (19,3,3);
INSERT INTO "invited" (event_id,invited_id,inviter_id) VALUES (3,15,27);
INSERT INTO "invited" (event_id,invited_id,inviter_id) VALUES (19,29,16);
INSERT INTO "invited" (event_id,invited_id,inviter_id) VALUES (8,2,11);
INSERT INTO "invited" (event_id,invited_id,inviter_id) VALUES (12,18,5);
INSERT INTO "invited" (event_id,invited_id,inviter_id) VALUES (7,13,2);
INSERT INTO "invited" (event_id,invited_id,inviter_id) VALUES (8,9,12);
INSERT INTO "invited" (event_id,invited_id,inviter_id) VALUES (18,12,25);
INSERT INTO "invited" (event_id,invited_id,inviter_id) VALUES (4,18,23);
INSERT INTO "invited" (event_id,invited_id,inviter_id) VALUES (17,8,19);
INSERT INTO "invited" (event_id,invited_id,inviter_id) VALUES (4,2,15);
INSERT INTO "invited" (event_id,invited_id,inviter_id) VALUES (8,18,5);
INSERT INTO "invited" (event_id,invited_id,inviter_id) VALUES (6,19,4);
INSERT INTO "invited" (event_id,invited_id,inviter_id) VALUES (20,8,2);
INSERT INTO "invited" (event_id,invited_id,inviter_id) VALUES (11,8,8);
INSERT INTO "invited" (event_id,invited_id,inviter_id) VALUES (10,25,5);
INSERT INTO "invited" (event_id,invited_id,inviter_id) VALUES (8,30,14);
INSERT INTO "invited" (event_id,invited_id,inviter_id) VALUES (2,17,8);
INSERT INTO "invited" (event_id,invited_id,inviter_id) VALUES (15,27,23);
INSERT INTO "invited" (event_id,invited_id,inviter_id) VALUES (4,14,30);
INSERT INTO "invited" (event_id,invited_id,inviter_id) VALUES (15,25,28);
INSERT INTO "invited" (event_id,invited_id,inviter_id) VALUES (2,16,22);
INSERT INTO "invited" (event_id,invited_id,inviter_id) VALUES (3,2,12);
INSERT INTO "invited" (event_id,invited_id,inviter_id) VALUES (9,11,7);
INSERT INTO "invited" (event_id,invited_id,inviter_id) VALUES (6,10,9);
INSERT INTO "invited" (event_id,invited_id,inviter_id) VALUES (18,13,30);


INSERT INTO "comment" (id,commenter_id,event_id,content,removed) VALUES (1,11,8,'non, sollicitudin a, malesuada id, erat. Etiam vestibulum','No');
INSERT INTO "comment" (id,commenter_id,event_id,content,removed) VALUES (2,12,7,'tellus. Suspendisse sed dolor. Fusce mi lorem,','No');
INSERT INTO "comment" (id,commenter_id,event_id,content,removed) VALUES (3,2,18,'imperdiet dictum magna. Ut tincidunt orci','No');
INSERT INTO "comment" (id,commenter_id,event_id,content,removed) VALUES (4,5,3,'Proin sed turpis nec','No');
INSERT INTO "comment" (id,commenter_id,event_id,content,removed) VALUES (5,14,14,'ante. Maecenas mi felis,','No');
INSERT INTO "comment" (id,commenter_id,event_id,content,removed) VALUES (6,5,19,'tincidunt pede ac urna. Ut','No');
INSERT INTO "comment" (id,commenter_id,event_id,content,removed) VALUES (7,10,5,'ut lacus. Nulla tincidunt,','No');
INSERT INTO "comment" (id,commenter_id,event_id,content,removed) VALUES (8,10,15,'ornare, facilisis eget, ipsum. Donec sollicitudin adipiscing','No');
INSERT INTO "comment" (id,commenter_id,event_id,content,removed) VALUES (9,29,17,'magna tellus faucibus leo, in lobortis tellus','No');
INSERT INTO "comment" (id,commenter_id,event_id,content,removed) VALUES (10,14,4,'ipsum porta elit, a feugiat tellus lorem','No');
INSERT INTO "comment" (id,commenter_id,event_id,content,removed) VALUES (11,8,8,'ridiculus mus. Proin vel nisl. Quisque fringilla euismod','No');
INSERT INTO "comment" (id,commenter_id,event_id,content,removed) VALUES (12,29,5,'eget ipsum. Suspendisse sagittis.','No');
INSERT INTO "comment" (id,commenter_id,event_id,content,removed) VALUES (13,15,20,'pretium aliquet, metus urna convallis','No');
INSERT INTO "comment" (id,commenter_id,event_id,content,removed) VALUES (14,23,18,'sed tortor. Integer aliquam','No');
INSERT INTO "comment" (id,commenter_id,event_id,content,removed) VALUES (15,11,11,'amet ultricies sem magna nec quam. Curabitur vel','No');
INSERT INTO "comment" (id,commenter_id,event_id,content,removed) VALUES (16,21,3,'ac metus vitae velit','No');
INSERT INTO "comment" (id,commenter_id,event_id,content,removed) VALUES (17,10,9,'sed leo. Cras vehicula aliquet libero. Integer in','No');
INSERT INTO "comment" (id,commenter_id,event_id,content,removed) VALUES (18,25,2,'malesuada malesuada. Integer id magna et ipsum cursus','No');
INSERT INTO "comment" (id,commenter_id,event_id,content,removed) VALUES (19,25,16,'quam quis diam. Pellentesque','No');
INSERT INTO "comment" (id,commenter_id,event_id,content,removed) VALUES (20,29,3,'quam quis diam. Pellentesque habitant','No');


INSERT INTO "report" (id,comment_id,report_note) VALUES (1,1,'nec tempus scelerisque, lorem ipsum');
INSERT INTO "report" (id,comment_id,report_note) VALUES (2,17,'non, sollicitudin a,');
INSERT INTO "report" (id,comment_id,report_note) VALUES (3,10,'eu odio tristique pharetra.');
INSERT INTO "report" (id,comment_id,report_note) VALUES (4,16,'eget, venenatis a, magna.');
INSERT INTO "report" (id,comment_id,report_note) VALUES (5,14,'velit in aliquet lobortis, nisi nibh');


INSERT INTO "notification" (id,target_id,TYPE,origin_id,description) VALUES (1,21,'invite',20,'Proin non massa non');
INSERT INTO "notification" (id,target_id,TYPE,origin_id,description) VALUES (2,22,'report',12,'sit amet ante. Vivamus');
INSERT INTO "notification" (id,target_id,TYPE,origin_id,description) VALUES (3,27,'changes',4,'luctus ut, pellentesque');
INSERT INTO "notification" (id,target_id,TYPE,origin_id,description) VALUES (4,2,'report',3,'convallis dolor. Quisque');
INSERT INTO "notification" (id,target_id,TYPE,origin_id,description) VALUES (5,12,'changes',15,'arcu. Vestibulum ante');
INSERT INTO "notification" (id,target_id,TYPE,origin_id,description) VALUES (6,12,'comment',10,'rutrum lorem ac');
INSERT INTO "notification" (id,target_id,TYPE,origin_id,description) VALUES (7,4,'comment',13,'metus urna convallis');
INSERT INTO "notification" (id,target_id,TYPE,origin_id,description) VALUES (8,20,'report',8,'enim diam');
INSERT INTO "notification" (id,target_id,TYPE,origin_id,description) VALUES (9,18,'report',3,'a sollicitudin orci sem');
INSERT INTO "notification" (id,target_id,TYPE,origin_id,description) VALUES (10,18,'comment',16,'nisi dictum');
INSERT INTO "notification" (id,target_id,TYPE,origin_id,description) VALUES (11,15,'comment',11,'enim. Mauris quis turpis');
INSERT INTO "notification" (id,target_id,TYPE,origin_id,description) VALUES (12,30,'invite',1,'at, egestas');
INSERT INTO "notification" (id,target_id,TYPE,origin_id,description) VALUES (13,21,'comment',18,'ligula. Nullam enim. Sed');
INSERT INTO "notification" (id,target_id,TYPE,origin_id,description) VALUES (14,20,'changes',7,'ornare tortor at risus.');
INSERT INTO "notification" (id,target_id,TYPE,origin_id,description) VALUES (15,5,'comment',12,'In nec orci.');
INSERT INTO "notification" (id,target_id,TYPE,origin_id,description) VALUES (16,1,'report',17,'fringilla, porttitor vulputate,');
INSERT INTO "notification" (id,target_id,TYPE,origin_id,description) VALUES (17,15,'report',11,'vestibulum massa');
INSERT INTO "notification" (id,target_id,TYPE,origin_id,description) VALUES (18,30,'report',9,'in, tempus eu,');
INSERT INTO "notification" (id,target_id,TYPE,origin_id,description) VALUES (19,15,'changes',9,'amet, risus. Donec');
INSERT INTO "notification" (id,target_id,TYPE,origin_id,description) VALUES (20,24,'comment',10,'Donec feugiat');



INSERT INTO "tags" (id,tag,event_id) VALUES (1,'erat',12);
INSERT INTO "tags" (id,tag,event_id) VALUES (2,'cursus',8);
INSERT INTO "tags" (id,tag,event_id) VALUES (3,'consectetuer',11);
INSERT INTO "tags" (id,tag,event_id) VALUES (4,'dolor,',11);
INSERT INTO "tags" (id,tag,event_id) VALUES (5,'aliquet',19);
INSERT INTO "tags" (id,tag,event_id) VALUES (6,'risus.',14);
INSERT INTO "tags" (id,tag,event_id) VALUES (7,'lorem',9);
INSERT INTO "tags" (id,tag,event_id) VALUES (8,'quis',9);
INSERT INTO "tags" (id,tag,event_id) VALUES (9,'eros',8);
INSERT INTO "tags" (id,tag,event_id) VALUES (10,'sit',12);
INSERT INTO "tags" (id,tag,event_id) VALUES (11,'ac',17);
INSERT INTO "tags" (id,tag,event_id) VALUES (12,'nec',11);
INSERT INTO "tags" (id,tag,event_id) VALUES (13,'dolor',16);
INSERT INTO "tags" (id,tag,event_id) VALUES (14,'turpis.',17);
INSERT INTO "tags" (id,tag,event_id) VALUES (15,'orci',19);
INSERT INTO "tags" (id,tag,event_id) VALUES (16,'est.',17);
INSERT INTO "tags" (id,tag,event_id) VALUES (17,'non',4);
INSERT INTO "tags" (id,tag,event_id) VALUES (18,'sit',19);
INSERT INTO "tags" (id,tag,event_id) VALUES (19,'semper.',5);
INSERT INTO "tags" (id,tag,event_id) VALUES (20,'hendrerit',3);


INSERT INTO "poll" (id,question,event_id,target_id) VALUES (1,'Proin sed turpis nec mauris blandit mattis.',12,8);
INSERT INTO "poll" (id,question,event_id,target_id) VALUES (2,'laoreet ipsum. Curabitur consequat, lectus sit amet',20,12);
INSERT INTO "poll" (id,question,event_id,target_id) VALUES (3,'semper cursus. Integer mollis.',14,18);
INSERT INTO "poll" (id,question,event_id,target_id) VALUES (4,'orci quis lectus. Nullam suscipit, est',6,17);
INSERT INTO "poll" (id,question,event_id,target_id) VALUES (5,'tempus scelerisque, lorem ipsum sodales purus, in molestie',4,11);
INSERT INTO "poll" (id,question,event_id,target_id) VALUES (6,'magna, malesuada vel, convallis in,',1,11);
INSERT INTO "poll" (id,question,event_id,target_id) VALUES (7,'sodales at, velit. Pellentesque ultricies dignissim lacus.',14,23);
INSERT INTO "poll" (id,question,event_id,target_id) VALUES (8,'convallis convallis dolor. Quisque',20,5);
INSERT INTO "poll" (id,question,event_id,target_id) VALUES (9,'tortor. Nunc commodo auctor velit.',20,13);
INSERT INTO "poll" (id,question,event_id,target_id) VALUES (10,'Donec feugiat metus sit',16,7);


INSERT INTO "option" (poll_id,content) VALUES (4,'nibh enim, gravida sit amet,');
INSERT INTO "option" (poll_id,content) VALUES (4,'Quisque fringilla euismod enim. Etiam');
INSERT INTO "option" (poll_id,content) VALUES (3,'Curabitur ut odio vel');
INSERT INTO "option" (poll_id,content) VALUES (2,'In lorem. Donec');
INSERT INTO "option" (poll_id,content) VALUES (1,'gravida sagittis. Duis');
INSERT INTO "option" (poll_id,content) VALUES (7,'sem. Nulla interdum.');
INSERT INTO "option" (poll_id,content) VALUES (3,'ut, molestie in,');
INSERT INTO "option" (poll_id,content) VALUES (9,'molestie sodales. Mauris');
INSERT INTO "option" (poll_id,content) VALUES (3,'venenatis vel,');
INSERT INTO "option" (poll_id,content) VALUES (5,'Suspendisse tristique neque venenatis lacus.');
INSERT INTO "option" (poll_id,content) VALUES (6,'erat. Etiam');
INSERT INTO "option" (poll_id,content) VALUES (3,'mauris a nunc.');
INSERT INTO "option" (poll_id,content) VALUES (4,'at, velit. Pellentesque ultricies dignissim');
INSERT INTO "option" (poll_id,content) VALUES (10,'posuere, enim nisl elementum purus, accumsan');
INSERT INTO "option" (poll_id,content) VALUES (9,'Sed eu eros. Nam consequat dolor');
INSERT INTO "option" (poll_id,content) VALUES (8,'Nulla eget');
INSERT INTO "option" (poll_id,content) VALUES (3,'massa lobortis');
INSERT INTO "option" (poll_id,content) VALUES (10,'aliquet diam.');
INSERT INTO "option" (poll_id,content) VALUES (7,'Nullam velit dui, semper et,');
INSERT INTO "option" (poll_id,content) VALUES (7,'et ultrices posuere');
INSERT INTO "option" (poll_id,content) VALUES (7,'ac sem');
INSERT INTO "option" (poll_id,content) VALUES (10,'consectetuer adipiscing');
INSERT INTO "option" (poll_id,content) VALUES (2,'venenatis a,');
INSERT INTO "option" (poll_id,content) VALUES (5,'pharetra');
INSERT INTO "option" (poll_id,content) VALUES (9,'dictum eu,');
INSERT INTO "option" (poll_id,content) VALUES (1,'in,');
INSERT INTO "option" (poll_id,content) VALUES (7,'Donec est mauris,');
INSERT INTO "option" (poll_id,content) VALUES (7,'In');
INSERT INTO "option" (poll_id,content) VALUES (8,'id,');


INSERT INTO "vote" (poll_id,voter_id,content) VALUES (7,18,'et ultrices posuere');
INSERT INTO "vote" (poll_id,voter_id,content) VALUES (7,7,'Nullam velit dui, semper et,');
INSERT INTO "vote" (poll_id,voter_id,content) VALUES (2,25,'venenatis a,');
INSERT INTO "vote" (poll_id,voter_id,content) VALUES (10,29,'consectetuer adipiscing');
INSERT INTO "vote" (poll_id,voter_id,content) VALUES (7,14,'ac sem');
INSERT INTO "vote" (poll_id,voter_id,content) VALUES (5,5,'pharetra');
INSERT INTO "vote" (poll_id,voter_id,content) VALUES (9,22,'dictum eu,');
INSERT INTO "vote" (poll_id,voter_id,content) VALUES (7,19,'Donec est mauris,');
INSERT INTO "vote" (poll_id,voter_id,content) VALUES (1,8,'in,');
INSERT INTO "vote" (poll_id,voter_id,content) VALUES (7,12,'In');
INSERT INTO "vote" (poll_id,voter_id,content) VALUES (8,5,'id,');

INSERT INTO "event_image" (event_id,image_url) VALUES (1,'a');
INSERT INTO "event_image" (event_id,image_url) VALUES (1,'b');
INSERT INTO "event_image" (event_id,image_url) VALUES (1,'c');
INSERT INTO "event_image" (event_id,image_url) VALUES (2,'a');
INSERT INTO "event_image" (event_id,image_url) VALUES (3,'b');
INSERT INTO "event_image" (event_id,image_url) VALUES (4,'c');
INSERT INTO "event_image" (event_id,image_url) VALUES (4,'a');
INSERT INTO "event_image" (event_id,image_url) VALUES (4,'b');
INSERT INTO "event_image" (event_id,image_url) VALUES (5,'c');


-----------------------------------------
-- end
-----------------------------------------

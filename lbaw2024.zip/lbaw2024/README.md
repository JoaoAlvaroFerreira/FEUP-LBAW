# Lbaw2024

### Meetcamp

An event manager for social gatherings.


### Group 24

* João Álvaro Cardoso Soares Ferreira, up201605592@fe.up.pt
* José Diogo da Cunha Moreira Trindade Martins, up201504761@fe.up.pt
* Mariana Monteiro e Neto, up201606791@fe.up.pt
* Nuno Rodrigues de Castro Santos Silva, up201404676@fe.up.pt


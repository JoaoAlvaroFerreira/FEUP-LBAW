@include('layouts.header')

@include('layouts.navbar')
    
<div class="app">
  <ul class="list-inline">
    <li class="list-inline-item">
      <h3 class="title">Search results for </h3></li>
    <li class="list-inline-item">
        <h4>"Sushi"</h4></li>
    <li class="list-inline-item">
      <div class="dropdown">
        <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Sort by
        </button>
        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
          <a class="dropdown-item" href="#">Popularity</a>
          <a class="dropdown-item" href="#">Date</a>
          <a class="dropdown-item" href="#">Price</a>
          <a class="dropdown-item" href="#">Location</a>
        </div>
    </div></li>
  </ul>
  
</div>
<div class="app">
  <h2 class="title">Events</h2>

  <ul class="hs">
    
    <li class="item">
      <img class="event" width="341px" height="226px" src="https://nit.pt/wp-content/uploads/2018/01/940bcc7d6d0eed8ec161fe7fec7ab2ae-754x394.jpg">
      <h3>Sushi Taste Test</h3>
      <p>20-03-2020 | 441 Paul Russell Rd</p>
      <a class="btn btn-outline-info" href="{{ url('/event') }}" role="button">See more</a>
    </li>
    <li class="item">
      <img class="event" width="341px" height="226px" src="https://www.atsukoskitchen.com/wp-content/uploads/2018/12/sushi-class.jpg">
      <h3>Ramen and Sushi Masterclass</h3>
      <p>20-03-2020 | 441 Paul Russell Rd</p>
      <a class="btn btn-outline-info" href="{{ url('/event') }}" role="button">See more</a>
    </li>
  </ul>
</div>

<div class="app">
  <h2 class="title">Users</h2>

  <ul class="hs">
    
    <li class="item">
      <img class="event" width="200px" height="200px" src="https://www.dhresource.com/600x600/f2/albu/g10/M01/54/D5/rBVaVly0LqKAROW6ABflxI6JLMk104.jpg">
      <h3>Sushi Lover</h3>
      <a class="btn btn-outline-info" href="{{ url('/user') }}" role="button">See more</a>
    </li>
    
  </ul>

</div>

@include('layouts.footer')
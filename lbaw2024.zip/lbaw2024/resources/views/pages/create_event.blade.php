@include('layouts.header')

@include('layouts.navbar')

<form class="container form-signin">
           
           <br></br>
           <h1 class="h3 h1-responsive font-weight-light text-center mb-3">New Event</h1>

           <div class="form-group row justify-content-center">
               <div class="col-md-7">
           
               <input type="text" id="eventName" class="form-control" placeholder="Name" required="" autofocus="">
               </div>
           </div>

           
           <div class="form-group row justify-content-center">
               <div class="col-md-7">
           
               <input type="text" id="eventDescription" class="form-control" placeholder="Description" required="" autofocus="">
               </div>
           </div>

           <div class="form-group row justify-content-center">
             <div class="col-md-7">
         
             <input type="text" id="eventPrice" class="form-control" placeholder="Price" required="" autofocus="">
             </div>
          </div>

           <div class="form-group row justify-content-center">
               <div class="col-md-7">
           

                   <div class="input-group date" data-provide="datepicker">
                       <input type="text" placeholder="Date" class="form-control">
                       <div class="input-group-addon">
                       <span class="glyphicon glyphicon-th"></span>
                       </div>
                   </div> 
                 </div>
           </div>
           
           
           <div class="form-group row justify-content-center">
               <div class="col-md-7">
              
               <input type="text" id="eventTags" class="form-control" placeholder="Tags" required="" autofocus="">
               </div>
           </div>
           <div class="form-group row justify-content-center">
               <div class="col-md-7">
              
                   <input type="text" id="eventLocation" class="form-control" placeholder="Location" required="" autofocus="">
                   <iframe width="100%" height="350" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.co.uk/maps?f=q&source=s_q&hl=en&geocode=&q=15+Springfield+Way,+Hythe,+CT21+5SH&aq=t&sll=52.8382,-2.327815&sspn=8.047465,13.666992&ie=UTF8&hq=&hnear=15+Springfield+Way,+Hythe+CT21+5SH,+United+Kingdom&t=m&z=14&ll=51.077429,1.121722&output=embed"></iframe>
                   
               </div>
           </div>
           
           <div class="text-center"> 
               <a class="btn btn-sm btn-info" href="{{ url('/event') }}" type="submit">Submit Event!</a>
                   </div>
       </div>
       
           
       </form>
         
 
        

@include('layouts.footer')
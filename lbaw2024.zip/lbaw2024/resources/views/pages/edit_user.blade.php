@include('layouts.header')

@include('layouts.navbar')

<div class="container" style="padding-top: 60px;">
  <h1 class="page-header"> Edit Profile</h1>


      <form method="post" action="{{ route('user.update', $user->id) }}" role="form" enctype="multipart/form-data">
        @method('PATCH')
        @csrf

        <div class="row">
        <!-- left column -->
        <div class="form-group row">
          <label for="photo" class="col-md-4 col-form-label text-md-right">Profile Image</label>
            <div class="col-md-6">
            <input id="photo" type="file" class="form-control" name="photo">
              @if (auth()->user()->photo)
               <code>{{ auth()->user()->photo }}</code>
             @endif
            </div>
         </div>
        <!-- Col Separator-->
        <div class="row">
          <div class="col-md-6 col-md-border"></div>
          <div class="col-md-6 col-md-border"></div>
        </div>
        <!-- EDIT FORM - NEEDS TO INCLUDE IMAGE NOW -->
        <div class="col-md-5 col-sm-6 col-xs-11 personal-info">

          <h3>Personal info</h3>

        <div class="form-group">
          <label class="col-lg-3 control-label">Full Name:</label>
          <div class="col-lg-8">
            <input class="form-control" type="text" name="name" value="{{ $user->name }}" />
          </div>
        </div>
        <div class="form-group">
          <label class="col-lg-3 control-label">Bio:</label>
          <div class="col-lg-8">
            <input class="form-control" name="bio" value="{{ $user->bio }}" type="text">
          </div>
        </div>
        <div class="form-group">
          <label class="col-lg-3 control-label">Email:</label>
          <div class="col-lg-8">
            <input class="form-control" type="email" name="email" value="{{ $user->email}}" />
          </div>
        </div>


        <div class="form-group">
          <label class="col-md-3 control-label"></label>
          <div class="col-md-8">
            <button class="btn btn-primary" type="submit">Submit Changes!</button>
            <span></span>
            <a class="btn btn-primary" href="/user/{{ $user->id }}" type="submit">Cancel</a>

          </div>
        </div>
      </form>
      <!-- DELETE FORM -->
      <div class="form-group">
        <form action="{{route('user.delete', $user->id)}}" method="post">
          <input class="btn btn-danger" onclick="return confirm('Are you sure?')" type="submit" value="Delete" />
          @method('delete')
          @csrf
        </form>
       
      </div>
    </div>
  </div>
</div>
<b></b>



@include('layouts.footer')
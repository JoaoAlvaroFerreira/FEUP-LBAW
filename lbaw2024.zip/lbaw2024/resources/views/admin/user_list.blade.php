@include('layouts.header')

@include('layouts.navbar')

<div class="mt-3 ml-3 md-3 mr-3">
<table class="table table-hover">
  <thead class="thead-dark">
    <tr>
      <th scope="col">ID</th>
      <th scope="col">Name</th>
      <th scope="col">Join Date</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">1</th>
      <td><a href="#">Mark Otto</a></td>
      <td>16/08/2019</td>
      <td><button type="button" class="btn btn-danger">Ban</button></td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td><a href="#">Jacob Thornton</a></td>
      <td>01/02/2019</td>
      <td><button type="button" class="btn btn-danger">Ban</button></td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td><a href="#">Larry Sanchez</a></td>
      <td>21/03/2019</td>
      <td><button type="button" class="btn btn-danger">Ban</button></td>
    </tr>
  </tbody>
</table>
</div>


@include('layouts.footer')
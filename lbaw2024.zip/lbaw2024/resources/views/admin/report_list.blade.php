@include('layouts.header')

@include('layouts.navbar')


<div class="mt-3 ml-3 md-3 mr-3">
<table class="table table-hover">
  <thead class="thead-dark">
    <tr>
      <th scope="col">ID</th>
      <th scope="col">Reporter</th>
      <th scope="col">Report Type</th>
      <th scope="col">Report Note</th>
      <th scope="col">Link</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">1</th>
      <td><a href="#">Mark Otto</a></td>
      <td>Comment</td>
      <td>The user is very insulting about the event</td>
      <td><button type="button" class="btn btn-info">See Origin</button></td>
    </tr>
    <tr>
       <th scope="row">2</th>
      <td><a href="#">Rachel Sanders</a></td>
      <td>Profile</td>
      <td>The user has an offensive profile image.</td>
      <td><button type="button" class="btn btn-info">See Origin</button></td>
    </tr>
    <tr>
    <th scope="row">3</th>
      <td><a href="#">Vivian Redfield</a></td>
      <td>Comment</td>
      <td>This comment reveals private information about other users.</td>
      <td><button type="button" class="btn btn-info">See Origin</button></td>
    </tr>
  </tbody>
</table>
</div>


@include('layouts.footer')
<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


// Authentication

Route::get('login', 'Auth\LoginController@showLoginForm')->name('login');
Route::post('login', 'Auth\LoginController@login');
Route::get('logout', 'Auth\LoginController@logout')->name('logout');
Route::get('register', 'Auth\RegisterController@showRegistrationForm')->name('register');
Route::post('register', 'Auth\RegisterController@register');

//User
Route::get('/user/{id}','UserController@show');
Route::get('/edit_user/{id}', 'UserController@edit');
Route::patch('/edit_user/{id}', 'UserController@update')->name('user.update');
Route::delete('/delete_user/{id}', 'UserController@delete')->name('user.delete');
//Route::post('/edit_user/{id}', 'UserController@update_photo')->name('user.update');


Route::get('/', 'WebController@index');

Route::get('/FAQ','WebController@faq');


Route::get('/About','WebController@about');

Route::get('/search','WebController@search');


Route::get('/event','WebController@event');


Route::get('/create_event','WebController@create_event');


Route::get('/edit_event','WebController@edit_event');




Route::get('/edit_user','WebController@edit_user');


Route::get('/user_list','AdminController@user_list');
Route::get('/report_list','AdminController@report_list');

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container" style="padding-top: 60px;">
  <h1 class="page-header"> Edit Profile</h1>


      <form method="post" action="<?php echo e(route('user.update', $user->id)); ?>" role="form" enctype="multipart/form-data">
        <?php echo method_field('PATCH'); ?>
        <?php echo csrf_field(); ?>

        <div class="row">
        <!-- left column -->
        <div class="form-group row">
          <label for="photo" class="col-md-4 col-form-label text-md-right">Profile Image</label>
            <div class="col-md-6">
            <input id="photo" type="file" class="form-control" name="photo">
              <?php if(auth()->user()->photo): ?>
               <code><?php echo e(auth()->user()->photo); ?></code>
             <?php endif; ?>
            </div>
         </div>
        <!-- Col Separator-->
        <div class="row">
          <div class="col-md-6 col-md-border"></div>
          <div class="col-md-6 col-md-border"></div>
        </div>
        <!-- EDIT FORM - NEEDS TO INCLUDE IMAGE NOW -->
        <div class="col-md-5 col-sm-6 col-xs-11 personal-info">

          <h3>Personal info</h3>

        <div class="form-group">
          <label class="col-lg-3 control-label">Full Name:</label>
          <div class="col-lg-8">
            <input class="form-control" type="text" name="name" value="<?php echo e($user->name); ?>" />
          </div>
        </div>
        <div class="form-group">
          <label class="col-lg-3 control-label">Bio:</label>
          <div class="col-lg-8">
            <input class="form-control" name="bio" value="<?php echo e($user->bio); ?>" type="text">
          </div>
        </div>
        <div class="form-group">
          <label class="col-lg-3 control-label">Email:</label>
          <div class="col-lg-8">
            <input class="form-control" type="email" name="email" value="<?php echo e($user->email); ?>" />
          </div>
        </div>


        <div class="form-group">
          <label class="col-md-3 control-label"></label>
          <div class="col-md-8">
            <button class="btn btn-primary" type="submit">Submit Changes!</button>
            <span></span>
            <a class="btn btn-primary" href="/user/<?php echo e($user->id); ?>" type="submit">Cancel</a>

          </div>
        </div>
      </form>
      <!-- DELETE FORM -->
      <div class="form-group">
        <form action="<?php echo e(route('user.delete', $user->id)); ?>" method="post">
          <input class="btn btn-danger" onclick="return confirm('Are you sure?')" type="submit" value="Delete" />
          <?php echo method_field('delete'); ?>
          <?php echo csrf_field(); ?>
        </form>
       
      </div>
    </div>
  </div>
</div>
<b></b>



<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/Mariana/Documents/lbaw2024/resources/views/pages/edit_user.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
    <img src="<?php echo e(asset('images/logo.png')); ?>" alt="Meetcamp Logo" height="60px" width="260px">
  </a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('/FAQ')); ?>">FAQ</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('/About')); ?>">About Us</a>
      </li>
     

    
          <?php if(Auth::check()): ?>
          <li class="nav-item">
            <a class="nav-link" href="/user/<?php echo e(Auth::user()->id); ?>">My Profile</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo e(url('/')); ?>">Notifications</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo e(url('/')); ?>">Invites</a>
          </li>
          
        <li class="nav-item">
        <span class="nav-link">You are logged in as <b><?php echo e(Auth::user()->name); ?></b></span>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(url('/logout')); ?>">Log Out</a>
           
        </li>
        </li>
      
       
        <li class="nav-item">
        <a class="btn event_btn btn-info" role="button" href="<?php echo e(url('/create_event')); ?>">Add Event</a>
      </li>
      
        <?php else: ?>
        
          <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Authentication
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="<?php echo e(url('/login')); ?>">Sign In</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="<?php echo e(url('/register')); ?>">Register</a>
        </div>
      </li>
        
        <?php endif; ?>


      
     


    </ul>
    <form class="form-inline my-2 my-lg-0">
      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
      <a class="btn btn-outline-success my-2 my-sm-0" href="<?php echo e(url('/search')); ?>" >Search</a>
    </form>
  </div>
</nav>
</html><?php /**PATH /Users/Mariana/Documents/lbaw2024/resources/views/layouts/navbar.blade.php ENDPATH**/ ?>
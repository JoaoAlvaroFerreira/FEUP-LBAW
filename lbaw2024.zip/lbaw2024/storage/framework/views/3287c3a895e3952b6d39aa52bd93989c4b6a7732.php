<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="bg">
    <div class="card text-center transparent-card p-3 mx-auto">

        <form class="container form-signin" method="POST" action="<?php echo e(route('login')); ?>">
            <?php echo e(csrf_field()); ?>

            <h1 class="h3 mb-3 h1-responsive font-weight-light text-center">Sign In</h1>
            <div class="form-group row justify-content-center">
                <div class="col-md-7">
                    <label class="sr-only"  for="email">E-mail</label>
                    <input class="form-control" id="email" placeholder="E-Mail Address" type="email" name="email" value="<?php echo e(old('email')); ?>" required autofocus>
                    <?php if($errors->has('email')): ?>
                    <span class="error">
                        <?php echo e($errors->first('email')); ?>

                    </span>
                    <?php endif; ?>
                </div>
            </div>

            <div class="form-group row justify-content-center">
                <div class="col-md-7">

                    <label class="sr-only"  for="password">Password</label>
                    <input class="form-control" id="password" placeholder="Password" type="password" name="password" required>
                    <?php if($errors->has('password')): ?>
                    <span class="error">
                        <?php echo e($errors->first('password')); ?>

                    </span>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="text-center">
                <button class="btn btn-primary" type="submit">
                    Sign In
                </button>
               
            </div>
           
        </form>
        <div class="text-center mt-2">
            <p>Don't have an account? <a href="<?php echo e(route('register')); ?>">Register</a></p>
            </div>

            <div class="text-center mt-2">
                <button class="btn btn-social btn-google" type="submit">
                    <span class="fa fa-google"></span> Sign in with Google</button>
            </div>

            <div class="text-center mt-2">
                <button class="btn btn-social btn-facebook" type="submit">
                    <span class="fa fa-facebook"></span> Sign in with Facebook</button>
            </div>
    </div>
</div>

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/Mariana/Documents/lbaw2024/resources/views/auth/login.blade.php ENDPATH**/ ?>
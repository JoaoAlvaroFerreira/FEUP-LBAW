<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="app">
    <div class="row">
        <div class="d-flex justify-content-center col-sm-6 col-md-6">
          
        <img src="<?php echo e($user->photo); ?>" style="width: 50%; height: 60%;">          </div>
        <div class="row">
          <div class="col-md-6 col-md-border"></div>
          <div class="col-md-6 col-md-border"></div>
      </div>  

        <div class="col-sm-5 col-md-5">
            <blockquote>
                <p><?php echo e($user->name); ?></p> <small><cite title="Source Title"></cite></small>
                <p>Joined on <?php echo e($user->join_date); ?></p>
            </blockquote>
            <p> 
                <br
                /> <i class="glyphicon glyphicon-globe"></i> <?php echo e($user->bio); ?>

                <br /> </p>
                <div class="col-md-8">
                  <a class="btn btn-outline-info" href="/edit_user/<?php echo e($user->id); ?>" type="submit">Edit Profile</a>
                  
                  
                </div>
        </div>
    </div>


  <!-- Attending Events -->
  <div class="app">
    <h2 class="title">Attending Events</h2>

    <ul class="hs">
      <li class="item">
        <img class="event" width="341px" height="226px" src="https://i1.wp.com/outoftownblog.com/wp-content/uploads/2017/01/Hot-Air-Balloon-Fiesta-2017.jpg?fit=1024%2C681&ssl=1">
        
            <h3>Hot Air Balloon Festival</h3>
            <p>20-03-2020 | 441 Paul Russell Rd</p>
            <a class="btn btn-outline-info" href="event.html" role="button">See more</a>
      </li>
      <li class="item">
        <img class="event" width="341px" height="226px" src="https://cdn.wegow.com/media/events/monterey-jazz-festival-2019/monterey-jazz-festival-2019-1554719425.04.2560x1440.jpg">
        <h3>Smooth Jazz Festival</h3>
        <p>20-03-2020 | 441 Paul Russell Rd</p>
        <a class="btn btn-outline-info" href="event.html" role="button">See more</a>
      </li>
      <li class="item">
        <img class="event" width="341px" height="226px" src="https://nit.pt/wp-content/uploads/2018/01/940bcc7d6d0eed8ec161fe7fec7ab2ae-754x394.jpg">
        <h3>Sushi Taste Test</h3>
        <p>20-03-2020 | 441 Paul Russell Rd</p>
        <a class="btn btn-outline-info" href="event.html" role="button">See more</a>
      </li>
      <li class="item">
        <img class="event" width="341px" height="226px" src="https://photos.bandsintown.com/large/6904408.jpeg">
            <h3>Tame Impala Live</h3>
            <p>20-03-2020 | 441 Paul Russell Rd</p>
            <a class="btn btn-outline-info" href="event.html" role="button">See more</a>
      </li>
      <li class="item">
        <img class="event" width="341px" height="226px" src="https://media.timeout.com/images/105573629/1372/772/image.jpg">
        <h3>Lis Restaurant Opening</h3>
        <p>20-03-2020 | 441 Paul Russell Rd</p>
        <a class="btn btn-outline-info" href="event.html" role="button">See more</a>
      </li>
      <li class="item">
        <img class="event" width="341px" height="226px" src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRIq77kpi6UALmuqdX4F2eoyF9WeCZKfu4_1FzALsPrnj3A3ucD">
        <h3>Black Friday Sale</h3>
        <p>20-03-2020 | 441 Paul Russell Rd</p>
        <a class="btn btn-outline-info" href="event.html" role="button">See more</a>
      </li>
    </ul>
  </div>

    <!-- Created events -->

    <div class="app">
      <h2 class="title">Created events</h2>

      <ul class="hs">
        <li class="item">
          <img class="event" width="341px" height="226px" src="https://photos.bandsintown.com/large/6904408.jpeg">
              <h3>Tame Impala Live</h3>
              <p>20-03-2020 | 441 Paul Russell Rd</p>
              <a class="btn btn-outline-info" href="event.html" role="button">See more</a>
        </li>
        <li class="item">
          <img class="event" width="341px" height="226px" src="https://media.timeout.com/images/105573629/1372/772/image.jpg">
          <h3>Lis Restaurant Opening</h3>
          <p>20-03-2020 | 441 Paul Russell Rd</p>
          <a class="btn btn-outline-info" href="event.html" role="button">See more</a>
        </li>
        <li class="item">
          <img class="event" width="341px" height="226px" src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRIq77kpi6UALmuqdX4F2eoyF9WeCZKfu4_1FzALsPrnj3A3ucD">
          <h3>Black Friday Sale</h3>
          <p>20-03-2020 | 441 Paul Russell Rd</p>
          <a class="btn btn-outline-info" href="event.html" role="button">See more</a>
        </li>
        <li class="item">
          <img class="event" width="341px" height="226px" src="https://i1.wp.com/outoftownblog.com/wp-content/uploads/2017/01/Hot-Air-Balloon-Fiesta-2017.jpg?fit=1024%2C681&ssl=1">
              <h3>Hot Air Balloon Festival</h3>
              <p>20-03-2020 | 441 Paul Russell Rd</p>
              <a class="btn btn-outline-info" href="event.html" role="button">See more</a>
        </li>
        <li class="item">
          <img class="event" width="341px" height="226px" src="https://cdn.wegow.com/media/events/monterey-jazz-festival-2019/monterey-jazz-festival-2019-1554719425.04.2560x1440.jpg">
          <h3>Smooth Jazz Festival</h3>
          <p>20-03-2020 | 441 Paul Russell Rd</p>
          <a class="btn btn-outline-info" href="event.html" role="button">See more</a>
        </li>
        <li class="item">
          <img class="event" width="341px" height="226px" src="https://nit.pt/wp-content/uploads/2018/01/940bcc7d6d0eed8ec161fe7fec7ab2ae-754x394.jpg">
          <h3>Sushi Taste Test</h3>
          <p>20-03-2020 | 441 Paul Russell Rd</p>
          <a class="btn btn-outline-info" href="event.html" role="button">See more</a>
        </li>
      </ul>
    </div>
         
 
        

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/Mariana/Documents/lbaw2024/resources/views/pages/user.blade.php ENDPATH**/ ?>
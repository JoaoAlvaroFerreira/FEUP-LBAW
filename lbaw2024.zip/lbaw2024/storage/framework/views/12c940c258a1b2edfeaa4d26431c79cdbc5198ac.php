<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="bg">
  <div class="card text-center transparent-card p-3 mx-auto">

    <form class="container form-signin" method="POST" action="<?php echo e(route('register')); ?>">
      <?php echo e(csrf_field()); ?>

      <h1 class="h3 mb-3 h1-responsive font-weight-light text-center">Register</h1>

      <div class="form-group row justify-content-center">
        <div class="col-md-7">
          <label class="sr-only" for="name">Name</label>
          <input class="form-control" placeholder="Full Name" id="name" type="text" name="name" value="<?php echo e(old('name')); ?>" required autofocus>
          <?php if($errors->has('name')): ?>
          <span class="error">
            <?php echo e($errors->first('name')); ?>

          </span>
          <?php endif; ?>
        </div>
      </div>

      <div class="form-group row justify-content-center">
        <div class="col-md-7">
          <label class="sr-only" for="email">E-Mail Address</label>
          <input class="form-control" placeholder="E-Mail Address" id="email" type="email" name="email" value="<?php echo e(old('email')); ?>" required>
          <?php if($errors->has('email')): ?>
          <span class="error">
            <?php echo e($errors->first('email')); ?>

          </span>
          <?php endif; ?>
        </div>
      </div>

      <div class="form-group row justify-content-center">
        <div class="col-md-7">
          <label class="sr-only" for="password">Password</label>
          <input class="form-control" placeholder="Password" id="password" type="password" name="password" required>
          <?php if($errors->has('password')): ?>
          <span class="error">
            <?php echo e($errors->first('password')); ?>

          </span>
          <?php endif; ?>
        </div>
      </div>

      <div class="form-group row justify-content-center">
        <div class="col-md-7">
          <label class="sr-only" for="password-confirm">Confirm Password</label>
          <input class="form-control" placeholder="Password Confirmation" id="password-confirm" type="password" name="password_confirmation" required>
        </div>
      </div>
      <div class="text-center">
        <button class="btn btn-primary" type="submit">
          Register
        </button>

      </div>
   
    </form>
    <div class="text-center mt-2">
        <p>Already have an account? <a href="<?php echo e(route('login')); ?>">Sign In</a></p>
      </div>
    <div class="text-center mt-2">
                <button class="btn btn-social btn-google" type="submit">
                    <span class="fa fa-google"></span> Sign in with Google</button>
            </div>

            <div class="text-center mt-2">
                <button class="btn btn-social btn-facebook" type="submit">
                    <span class="fa fa-facebook"></span> Sign in with Facebook</button>
            </div>
  </div>
</div>


<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/Mariana/Documents/lbaw2024/resources/views/auth/register.blade.php ENDPATH**/ ?>
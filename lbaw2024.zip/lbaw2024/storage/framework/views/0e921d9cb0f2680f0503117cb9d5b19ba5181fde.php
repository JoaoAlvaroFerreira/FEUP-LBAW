<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

 <div id="myCarousel" class="carousel slide" data-interval="false"  data-ride="carousel">
        <ol class="carousel-indicators">
          <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
          <li data-target="#myCarousel" data-slide-to="1"></li>
          <li data-target="#myCarousel" data-slide-to="2"></li>
        </ol>

  <div class="carousel-inner">
    <div class="carousel-item active">
        <img class="first-slide" src="https://www.kikocosmetics.com/mediaObject/2019/collection/party-all-night/Collection_PartyAllNight_Lanidng-HeroTitleSubtitleDesktop/original/Collection_PartyAllNight_Lanidng-HeroTitleSubtitleDesktop.jpg" alt="Third slide">
        <div class="container">
          <div class="carousel-caption text-left">
            <h1>Friday Night Fever Party</h1>
            <p>A 70s themed party at the Flavor nightclub in Porto</p>
            <p><a class="btn btn-lg btn-info" href="#" role="button">Get tickets</a></p>
            </div>
        </div>
      </div>
          
          <div class="carousel-item">
            <img class="second-slide" src="https://www.visitportugal.com/sites/default/files/styles/encontre_detalhe_poi_destaque/public/mediateca/EDPBP%20Ambiente%202_660x371.jpg?itok=ilqD1HXq" alt="Second slide">
            <div class="container">
              <div class="carousel-caption">
                <h1>Friday Night Fever Party</h1>
                <p>A 70s themed party at the Flavor nightclub in Porto.</p>
                <p><a class="btn btn-lg btn-info" href="#" role="button">Get tickets</a></p>
               
              </div>
            </div>
          </div>
          <div class="carousel-item">
            <img class="third-slide" src="https://topnotchtalent.com/wp-content/uploads/holiday-party-entertainment-top-notch-talent.jpg" alt="First slide">
            <div class="container">
              <div class="carousel-caption text-right">
                <h1>Friday Night Fever Party!.</h1>
                <p>A 70s themed party at the Flavor nightclub in Porto.</p>
                <p><a class="btn btn-lg btn-info" href="#" role="button">Get tickets</a></p>
               
              </div>
            </div>
          </div>
        </div>
        <a class="carousel-control-prev" href="#myCarousel" role="button" data-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#myCarousel" role="button" data-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="sr-only">Next</span>
        </a>
      </div>


    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>

      <div class="text-center mb-5"><a class="btn btn-info" href="<?php echo e(url('/edit_event')); ?>" role="button">Edit Event &raquo;</a></div>       
   
      <!-- Marketing messaging and featurettes
      ================================================== -->
      <!-- Wrap the rest of the page in another container to center all the content. -->

      <div class="container mb-3">

        <!-- Three columns of text below the carousel -->
        <div class="row">
          <div class="col-lg-4 mb-5">
            <img class="rounded-circle" src="https://blogmedia.evbstatic.com/wp-content/uploads/wpmulti/sites/8/shutterstock_199419065.jpg" alt="Generic placeholder image" width="140" height="140">
            <h2>Going</h2>
            <p>Here's a list of all of our guests!</p>
            <p><a class="btn btn-outline-info" href="#" role="button">See List &raquo;</a></p>
          </div><!-- /.col-lg-4 -->
          <div class="col-lg-4">
            <img class="rounded-circle" src="https://investorplace.com/wp-content/uploads/2018/06/MSGmsn-compressor.jpg" alt="Generic placeholder image" width="140" height="140">
            <h2>Details</h2>
            <p>See event details such as venue address, time and date.</p>
            <p><a class="btn btn-outline-info" href="#" role="button">View details &raquo;</a></p>
          </div><!-- /.col-lg-4 -->
          <div class="col-lg-4">
            <img class="rounded-circle" src="https://images.squarespace-cdn.com/content/v1/53c4accae4b06821a4ea6026/1499622903049-7H80M83GZO2UITY70P1P/ke17ZwdGBToddI8pDm48kGx-n53ovtSa-l9_LFxn5Sh7gQa3H78H3Y0txjaiv_0fDoOvxcdMmMKkDsyUqMSsMWxHk725yiiHCCLfrh8O1z5QPOohDIaIeljMHgDF5CVlOqpeNLcJ80NK65_fV7S1UemzdZYhAG89oR4Chl5pXqeg215nnTZ1Imd0sAjsfnDNDz83YmSA7HB1mYBaOgQKFw/Friends+sharing+wine.jpg" alt="Generic placeholder image" width="140" height="140">
            <h2>Share with your friends</h2>
            <p>Invite others that might be interested in the event.</p>
            <p><a class="btn btn-outline-info" href="#" role="button">Share &raquo;</a></p>
          </div><!-- /.col-lg-4 -->
        </div><!-- /.row -->
      </div>


      <div class="comments mx-auto">
        <div class="row">
            <div class="col-md-offset-2 col-sm-12">
                <div class="comment-wrapper">
                    <div class="panel panel-info">
                        <div class="panel-heading">
                            Comment panel
                        </div>
                        <div class="panel-body">
                            <textarea class="form-control" placeholder="write a comment..." rows="3"></textarea>
                            <br>
                            <button type="button" class="btn btn-info pull-right">Post</button>
                            <div class="clearfix"></div>
                            <hr>
                            <ul class="media-list">
                                <li class="media">
                                    <a href="#" class="pull-left">
                                        <img src="https://bootdey.com/img/Content/user_1.jpg" alt="" class="img-circle">
                                    </a>
                                    <div class="media-body">
                                        <span class="text-muted pull-right">
                                            <small class="text-muted">40 min ago</small>
                                        </span>
                                        <strong class="text-success">Martin Richards</strong>
                                        <p>
                                            Estou ansioso por este evento <a href="#">#party </a>.
                                        </p>
                                    </div>
                                </li>
                                <li class="media">
                                    <a href="#" class="pull-left">
                                        <img src="https://bootdey.com/img/Content/user_2.jpg" alt="" class="img-circle">
                                    </a>
                                    <div class="media-body">
                                        <span class="text-muted pull-right">
                                            <small class="text-muted">32 min ago</small>
                                        </span>
                                        <strong class="text-success">Lauren North</strong>
                                        <p>
                                           O dress code é formal ou business casual?
                                        </p>
                                    </div>
                                </li>
                                <li class="media">
                                    <a href="#" class="pull-left">
                                        <img src="https://bootdey.com/img/Content/user_3.jpg" alt="" class="img-circle">
                                    </a>
                                    <div class="media-body">
                                        <span class="text-muted pull-right">
                                            <small class="text-muted">30 min ago</small>
                                        </span>
                                        <strong class="text-success">John Helder</strong>
                                        <p>
                                            É para ir de fato de banho colega!
                                        </p>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
        
            </div>
        </div>

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/Mariana/Documents/lbaw2024/resources/views/pages/event.blade.php ENDPATH**/ ?>
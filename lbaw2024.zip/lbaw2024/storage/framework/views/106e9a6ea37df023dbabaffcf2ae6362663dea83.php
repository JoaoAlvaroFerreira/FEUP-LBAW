<!DOCTYPE html>
<html>

   <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
 

<footer class="page-footer font-small blue">

  <!-- Copyright -->
  <div class="footer-copyright text-center text-muted py-3 static">© 2020 Copyright:
    <a href="<?php echo e(url('/')); ?>"> Meetcamp</a>
    <p>Admin Panel: <a href="<?php echo e(url('/admin_user_list')); ?>">Users</a> | <a href="<?php echo e(url('/admin_report_list')); ?>">Reports</a></p>
  </div>
  <!-- Copyright -->

</footer>
</html><?php /**PATH /Users/Mariana/Documents/lbaw2024/resources/views/layouts/footer.blade.php ENDPATH**/ ?>
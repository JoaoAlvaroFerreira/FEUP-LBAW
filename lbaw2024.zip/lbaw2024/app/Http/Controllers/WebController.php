<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;


class WebController extends Controller
{


    public function index(){
       
        return view('pages.home');
    }

    public function about() {
        
        return view('pages.about');
    }

    public function faq() {
        
        return view('pages.faq');
    }

    public function search() {
        
        return view('pages.search');

    }

    public function event() {
        
        return view('pages.event');
    }

    public function create_event() {
        
        return view('pages.create_event');
    }

    public function edit_event() {
        
        return view('pages.create_event');
    }

    public function edit_user() {
        
        return view('pages.edit_user');
    }


}

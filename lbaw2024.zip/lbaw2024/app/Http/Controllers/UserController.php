<?php

namespace App\Http\Controllers;

use App\Traits\UploadTrait;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Controller;
use App\User;
use Illuminate\Support\Str;

class UserController extends Controller
{
    use UploadTrait;


    public function __construct()
    {
        $this->middleware('auth');
    }

    public function show($id)
    {
        $user = User::find($id);


        return view('pages.user', ['user' => $user]);
    }


    public function edit($id)
    {
        $user = User::find($id);
        return view('pages.edit_user', compact('user'));
    }

    public function update(Request $request, $id)
    {
        $user = User::find($id);

        $request->validate([
            'name' => 'required',
            'bio' => 'max:255',
            'email' => 'required',
            'photo'  =>'image|mimes:jpeg,png,jpg,gif|max:2048'

        ]);

        $user->name = $request->get('name');
        $user->bio = $request->get('bio');
        $user->email = $request->get('email');

        // Check if a profile image has been uploaded
        if ($request->has('photo')) {
            // Get image file
            $image = $request->file('photo');
            // Make a image name based on user name and current timestamp
            $name = Str::slug($request->input('name')).'_'.time();
            // Define folder path
            $folder = '/uploads/images/';
            // Make a file path where image will be stored [ folder path + file name + file extension]
            $filePath = $folder . $name. '.' . $image->getClientOriginalExtension();
            // Upload image
            $this->uploadOne($image, $folder, 'public', $name);
            // Set user profile image path in database to filePath
            $user->photo = $filePath;
        }

        $user->save();


        return redirect('/')->with('success', 'User has been updated');
    }

    public function delete($id)
    {
        $user = User::find($id);
        $user->delete();

        return redirect('/')->with('success', 'Account has been deleted successfully');
    }
}

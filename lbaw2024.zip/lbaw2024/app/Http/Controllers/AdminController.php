<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AdminController extends Controller
{
    //
    
    public function admin_user_list(){
        return view('admin.user_list');
    }

    public function admin_report_list(){
        return view('admin.report_list');
    }
}
